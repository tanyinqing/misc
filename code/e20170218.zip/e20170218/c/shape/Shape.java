package e20170218.c.shape;

/**
 * Created by mingfei.net@gmail.com
 * 2/18/17 10:02
 */
// Shape.java文件，在该文件中定义接口 Shape，该接口在 c.shape 包中
// 域：PI
// 方法：求面积的方法 area
public interface Shape {

    /**
     * 圆周率 PI
     */
    double PI = 3.14159265358979323846;

    /**
     * 求面积的方法
     * @return 面积
     */
    double area();
}
